package com.candybar.dev.services;

import candybar.lib.services.CandyBarWidgetService;

public class ClockWidget extends CandyBarWidgetService {
}
