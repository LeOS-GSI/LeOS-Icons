package com.candybar.dev.services;

import candybar.lib.services.CandyBarMuzeiService;

public class MuzeiService extends CandyBarMuzeiService {
}
