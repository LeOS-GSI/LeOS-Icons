package candybar.lib.items;

public class ImageSize {
    public final int width;
    public final int height;

    public ImageSize(int width, int height) {
        this.width = width;
        this.height = height;
    }
}
